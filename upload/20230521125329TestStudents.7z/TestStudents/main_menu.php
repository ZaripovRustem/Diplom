<div class="sidenav">
    <a href="profileadmincurs.php">Кусы</a>
    <a href="profileadmin.php">Пользователи</a>
    <a href="report.php">Отчеты</a>
    <a href="vendor/logout.php" class="logout">Выход</a>
</div>
