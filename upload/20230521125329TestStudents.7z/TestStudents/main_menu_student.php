<div class="sidenav">
    <a href="profilestudent.php">Курсы</a>
    <a href="vendor/logout.php" class="logout">Выход</a>
</div>
